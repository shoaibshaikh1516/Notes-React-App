import { GET_NOTES_USING_PAGINATION } from './types';
import axios from 'axios';

export const getNotesWithPagination = (page, size) => async dispatch => {
  console.log("this is page, size", page, size);
  const res = await axios.get(
    `http://localhost:8080/api/notes?page=${page}&size=${size}`
  );
  // console.log(res.data.content);
  dispatch({ type: GET_NOTES_USING_PAGINATION, payload: res.data });
};


// export const updateNotesWithPG= contact => async dispatch => {
//   const res = await axios.put(
//     `https://jsonplaceholder.typicode.com/users/${contact.id}`,
//     contact
//   );
//   dispatch({
//     type: UPDATE_NOTES_USING_PAGINATION,
//     payload: res.data,
//   });
// };
