import React, { Component } from 'react';
import MainLogin from '../login/MainLogin';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
class Login extends Component {
  render() {
    return (
      <div className="row ">
        <div className="col-md-6 offset-3 ">
          <MainLogin />
        </div>
      </div>
    );
  }
}

export default Login;
