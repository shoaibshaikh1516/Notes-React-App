import {
  GET_NOTES_USING_PAGINATION,
  UPDATE_NOTES_USING_PAGINATION,
} from '../actions/types';
//same as Context file used previously
const initialState = {
  notespg: {},

  // contact: {},
};

export default function (state = initialState, action) {
  console.log(' reducer GET_NOTES_USING_PAGINATIONsss', action.payload);

  switch (action.type) {
    case GET_NOTES_USING_PAGINATION:
      return {
        ...state,
        notespg: action.payload,
      };

    case UPDATE_NOTES_USING_PAGINATION:
      return {
        ...state,
        contacts: state.contacts.map(contact =>
          contact.id === action.payload.id
            ? (contact = action.payload)
            : contact
        ),
      };
    default:
      return state;
  }
}
